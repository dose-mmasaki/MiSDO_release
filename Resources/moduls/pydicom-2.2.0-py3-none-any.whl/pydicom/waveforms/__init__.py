from pydicom.waveforms.numpy_handler import (
    generate_multiplex, multiplex_array
)
